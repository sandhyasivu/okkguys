<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php include('title.php') ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" /></head>
<body>
<div class="total">
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background:url(images/banner.jpg) no-repeat bottom">
  <tr>
    <td height="230" align="center" valign="top"><span class="menu"><?php include('menu.php') ?> </span></td>
  </tr>
</table>
<table width="100%" border="0" style="border-top:#FFFFFF solid 3px;">
  <tr>
    <td colspan="7">&nbsp;</td>
  </tr>
  <tr>
    <td height="53" colspan="7" align="center"><h1>About Us</h1></td>
  </tr>
  <tr>
    <td colspan="7">&nbsp;</td>
  </tr>
  <tr>
    <td width="5%" align="center">&nbsp;</td>
    <td width="24%" align="center" bgcolor="#FFFFFF">
    <p style="padding:20px 20px 20px 20px;text-align:justify;color:#000000">We have designed and developed a system called "<strong>LibraryManagement System </strong>" that finds its applications in various colleges. We have designed the front end by using <strong>PHP</strong> and Back End by <strong>MYSQL</strong></p></td>
    <td width="4%" align="center">&nbsp;</td>
    <td width="24%" align="center" bgcolor="#FFFFFF"><p style="padding:20px 20px 20px 20px;text-align:justify;color:#000000">&nbsp;</p></td>
    <td width="4%" align="center">&nbsp;</td>
    <td width="24%" align="center" bgcolor="#FFFFFF"><p style="padding:20px 20px 20px 20px;text-align:justify;color:#000000">.
</p></td>
    <td width="5%" align="center">&nbsp;</td>
  </tr>
  <tr>
     <td colspan="7">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" class="table2">
  <tr>
    <td height="60" align="center"><?php include('footer.php') ?></td>
  </tr>
</table>
</div>
</body>
</html>
