<a href="index.php">HOME</a>|
<a href="admin.php">ADMIN</a>|
<a href="sup.php">MEMBER</a>|
<a href="cust.php">LIBRARY</a>
